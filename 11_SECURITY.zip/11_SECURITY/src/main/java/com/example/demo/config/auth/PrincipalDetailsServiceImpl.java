package com.example.demo.config.auth;

import com.example.demo.domain.dto.UserDto;
import com.example.demo.domain.entity.User;
import com.example.demo.domain.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PrincipalDetailsServiceImpl implements UserDetailsService {
	@Autowired
	private UserRepository userRepository;

	@Override	// 중개함수, security가 아이디 패스워드를 검증하는 곳은 AuthenticationManager이다.
	// manager가 Provider단위로 받기때문에 Provider로 바꿔줘야 한다.
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User> userOptional = userRepository.findById(username);
		if(userOptional.isEmpty())
			throw new UsernameNotFoundException(username);

		User user = userOptional.get();

		// entity -> dto
		UserDto userDto = UserDto.builder()
				.username(user.getUsername())
				.password(user.getPassword())
				.role(user.getRole())
				.build();

		return new PrincipalDetails(userDto);
	}
	
}
