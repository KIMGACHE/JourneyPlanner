package com.example.demo.config.auth.loginHandler;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import java.io.IOException;
import java.util.Collection;

@Slf4j
public class CustomLoginSuccessHandler implements org.springframework.security.web.authentication.AuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        log.info("CustomLoginSuccessHandler's onAuthenticationSuccess() invoke..");

        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        authorities.forEach(role->{
            System.out.println("ROLE : "+role.getAuthority());
            try {
                if("ROLE_ADMIN".equals(role.getAuthority())) {
                    response.sendRedirect(request.getContextPath()+"/admin");
                    return ;
                } else if("ROLE_MEMBER".equals(role.getAuthority())) {
                    response.sendRedirect(request.getContextPath()+"/member");
                    return ;
                } else if("ROLE_USER".equals(role.getAuthority())) {
                    response.sendRedirect(request.getContextPath()+"/user");
                    return ;
                } else {
                    response.sendRedirect(request.getContextPath()+"/");
                    return ;
                }
            } catch(Exception e) {
                e.printStackTrace();
            }
        });
    }
}
