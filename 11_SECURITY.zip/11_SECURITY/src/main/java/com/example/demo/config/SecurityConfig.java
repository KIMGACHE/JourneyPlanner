package com.example.demo.config;

import com.example.demo.config.auth.exceptionHandler.CustomAccessDeniedHandler;
import com.example.demo.config.auth.exceptionHandler.CustomAuthenticationEntryPoint;
import com.example.demo.config.auth.loginHandler.CustomAuthenticatioFailureHandler;
import com.example.demo.config.auth.loginHandler.CustomLoginSuccessHandler;
import com.example.demo.config.auth.logoutHandler.CustomLogoutHandler;
import com.example.demo.config.auth.logoutHandler.CustomLogoutSuccessHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.rememberme.JdbcTokenRepositoryImpl;
import org.springframework.security.web.authentication.rememberme.PersistentTokenRepository;

import javax.sql.DataSource;
import javax.xml.crypto.Data;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Autowired
    private DataSource dataSource;

    @Bean
    public SecurityFilterChain config(HttpSecurity http) throws Exception {
        // CSRF 비활성화
        http.csrf((config)->{config.disable();}); // 플젝할땐 활성화 되어있어야함, 테스트를 위해 잠시 비활성화

        // 권한 체크
        http.authorizeHttpRequests((auth)->{
            auth.requestMatchers("/","/join","/login").permitAll(); // 모든 이용자가 접근할 수 있는 페이지를 매핑
            auth.requestMatchers("/user").hasRole("USER");  // USER권한을 가진 이용자만이 접근할 수 있는 페이지를 매핑
            auth.requestMatchers("/member").hasRole("MEMBER"); // MEMBER권한을 가진 이용자만이 접근할 수 있는 페이지를 매핑
            auth.requestMatchers("/admin").hasRole("ADMIN"); // ADMIN권한을 가진 이용자만이 접근할 수 있는 페이지를 매핑
            auth.anyRequest().authenticated();
        });

        // 로그인
        http.formLogin((login)->{
            login.permitAll();
            login.loginPage("/login");
            login.successHandler(new CustomLoginSuccessHandler());              // 로그인 성공시 처리
            login.failureHandler(new CustomAuthenticatioFailureHandler());      // 로그인 실패시 처리
        });

        // 로그아웃
        http.logout((logout)->{
            logout.permitAll();
            logout.logoutUrl("/logout");
            logout.addLogoutHandler(new CustomLogoutHandler());                 // 로그아웃 핸들러 여기서 forward나 redirect추천안함
            logout.logoutSuccessHandler(new CustomLogoutSuccessHandler());      // 로그인 성공시 처리
        });

        // 예외처리
        http.exceptionHandling((exception)->{
            exception.authenticationEntryPoint(new CustomAuthenticationEntryPoint());   // 인증되지않은 사용자(로그인안한 사용자) 처리
            exception.accessDeniedHandler(new CustomAccessDeniedHandler()); // 권한이 부족한 사용자 처리
        });

        // REMEMBER ME
        http.rememberMe((rm)->{
           rm.rememberMeParameter("remember-me");
           rm.alwaysRemember(false);    // 항상 rm킬거냐
           rm.tokenValiditySeconds(30*30);  // token 지속시간
           rm.tokenRepository(tokenRepository());    // token db crud?
        });

        return http.build();
    } // SecurityFilterChain을 Bean에 등록함

    @Bean
    public PersistentTokenRepository tokenRepository() {
        JdbcTokenRepositoryImpl repo = new JdbcTokenRepositoryImpl();
        repo.setDataSource(dataSource);

        return repo;
    }

    @Bean
    public PasswordEncoder passwordEncode() {
        return new BCryptPasswordEncoder();
    }


}
