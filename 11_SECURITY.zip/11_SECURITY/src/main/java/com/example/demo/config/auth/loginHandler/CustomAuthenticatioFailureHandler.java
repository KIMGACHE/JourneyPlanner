package com.example.demo.config.auth.loginHandler;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.AuthenticationException;
import org.yaml.snakeyaml.util.UriEncoder;

import java.io.IOException;

@Slf4j
public class CustomAuthenticatioFailureHandler implements org.springframework.security.web.authentication.AuthenticationFailureHandler {
    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
        log.info("CustomAuthenticatioFailureHandler's onAuthenticationFailure().."+exception);
        response.sendRedirect("/login?error="+ UriEncoder.encode(exception.getMessage()));  // getMessage에 한글 문자열이 포함되어있어서 에러가발생했음
    }
}
